//Evan Heaton
//CS216
//Lab9
//Is this even how header files work

#ifndef "FUNCTIONS_H"
#define "FUNCTIONS_H"

int* read_data(int &size);
int second_greatest(int* data, int size);

#endif
